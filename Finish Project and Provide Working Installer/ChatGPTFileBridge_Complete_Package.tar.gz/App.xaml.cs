// Part of WinBridgeAgent (c) 2025 Vladislav Manoilov
using System.Configuration;
using System.Data;
using System.Windows;

namespace WinBridgeAgentControlPanel
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        // Part of WinBridgeAgent (c) 2025 Vladislav Manoilov
    }

}

