## Licensing Notice

You are free to use, modify, and share **WinBridgeAgent** for personal and non-commercial purposes.

If you intend to use it in **any commercial product**, or in a way that generates revenue (directly or indirectly), you must:

1. **Credit the original creator**, Vladislav Manoilov  
2. **Contact me to agree on a fair revenue-sharing or licensing arrangement**

📫 Commercial Licensing Requests:  
→ Email: vlad [at] gmail [dot] com  
→ GitHub: https://github.com/vmanoilov  
(Use subject: “WinBridgeAgent Commercial License”)

Thanks for supporting ethical software!