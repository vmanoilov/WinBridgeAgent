# Comprehensive Build and Distribution Guide for WinBridgeAgent

This guide provides detailed step-by-step instructions on how to compile the WinBridgeAgent service, the WinBridgeAgent Control Panel GUI, build the NSIS installer, and distribute the final installer using GitHub releases.

## Table of Contents

1.  [Introduction](#introduction)
2.  [Prerequisites](#prerequisites)
    *   [Software Requirements](#software-requirements)
    *   [GitHub Account](#github-account)
3.  [Project Structure Overview](#project-structure-overview)
4.  [Step 1: Setting up the Development Environment](#step-1-setting-up-the-development-environment)
    *   [Installing .NET SDK](#installing-net-sdk)
    *   [Installing NSIS](#installing-nsis)
    *   [Installing Git](#installing-git)
    *   [Code Editor](#code-editor)
5.  [Step 2: Obtaining the Source Code](#step-2-obtaining-the-source-code)
    *   [Cloning from GitHub (if applicable)](#cloning-from-github-if-applicable)
    *   [Arranging Provided Source Files](#arranging-provided-source-files)
6.  [Step 3: Compiling the WinBridgeAgent Service](#step-3-compiling-the-winbridgeagent-service)
    *   [Navigating to the Service Project Directory](#navigating-to-the-service-project-directory)
    *   [Restoring Dependencies](#restoring-dependencies)
    *   [Building the Service](#building-the-service)
    *   [Publishing the Service (Self-Contained)](#publishing-the-service-self-contained)
7.  [Step 4: Compiling the WinBridgeAgent Control Panel GUI](#step-4-compiling-the-winbridgeagent-control-panel-gui)
    *   [Navigating to the GUI Project Directory](#navigating-to-the-gui-project-directory)
    *   [Restoring Dependencies](#restoring-dependencies-gui)
    *   [Building the GUI](#building-the-gui)
    *   [Publishing the GUI (Self-Contained)](#publishing-the-gui-self-contained)
8.  [Step 5: Preparing Files for the Installer](#step-5-preparing-files-for-the-installer)
    *   [Creating the `publish_output` Directory](#creating-the-publish_output-directory)
    *   [Copying Service Files](#copying-service-files)
    *   [Copying GUI Files](#copying-gui-files)
    *   [Copying `LICENSE.txt`](#copying-licensetxt)
9.  [Step 6: Building the NSIS Installer](#step-6-building-the-nsis-installer)
    *   [Navigating to the Installer Script Directory](#navigating-to-the-installer-script-directory)
    *   [Running the NSIS Compiler (`makensis`)](#running-the-nsis-compiler-makensis)
    *   [Locating the Installer Executable](#locating-the-installer-executable)
10. [Step 7: Setting up a GitHub Repository](#step-7-setting-up-a-github-repository)
    *   [Creating a New Repository on GitHub](#creating-a-new-repository-on-github)
    *   [Initializing a Local Git Repository](#initializing-a-local-git-repository)
    *   [Committing Project Files](#committing-project-files)
    *   [Linking Local Repository to GitHub](#linking-local-repository-to-github)
    *   [Pushing to GitHub](#pushing-to-github)
11. [Step 8: Creating a Release on GitHub](#step-8-creating-a-release-on-github)
    *   [Tagging a Release](#tagging-a-release)
    *   [Navigating to the Releases Page](#navigating-to-the-releases-page)
    *   [Drafting a New Release](#drafting-a-new-release)
    *   [Attaching the Installer Executable](#attaching-the-installer-executable)
    *   [Writing Release Notes](#writing-release-notes)
    *   [Publishing the Release](#publishing-the-release)
12. [Conclusion](#conclusion)

## 1. Introduction

WinBridgeAgent is a Windows service providing secure named-pipe access to a local folder, accompanied by a GUI Control Panel for management. This guide will walk you through the entire process from source code to a distributable installer hosted on GitHub.

## 2. Prerequisites

Before you begin, ensure you have the following software installed and accounts set up.

### Software Requirements

*   **.NET 8 SDK (or newer)**: For compiling the C# service and GUI projects.
*   **NSIS (Nullsoft Scriptable Install System)**: For compiling the installer script.
*   **Git**: For version control and interacting with GitHub.
*   **A Code Editor**: Such as Visual Studio, Visual Studio Code, or JetBrains Rider, for working with the source code.

### GitHub Account

*   A **GitHub account** is required to host the repository and create releases.

## 3. Project Structure Overview

It's assumed you have the following project components, which will be organized for the build process:

*   **WinBridgeAgent Service Source**: Contains the `.sln`, `.csproj`, and `.cs` files for the Windows service.
*   **WinBridgeAgent Control Panel GUI Source**: Contains the `.sln`, `.csproj`, `.xaml`, and `.cs` files for the WPF GUI application.
*   **WinBridgeAgent Installer Script**: An `.nsi` file (e.g., `WinBridgeAgentInstaller.nsi`).
*   **LICENSE.txt**: The license file for the project.

We will create a main project directory to house these components, for example:

```
WinBridgeAgent_Distribution/
|-- WinBridgeAgent/              (Source code for the service)
|   |-- WinBridgeAgent.sln
|   |-- WinBridgeAgent/
|       |-- WinBridgeAgent.csproj
|       |-- Program.cs
|       |-- appsettings.json
|       |-- Core/
|       |-- ... (other service source files)
|-- WinBridgeAgentAddons/
|   |-- WinBridgeAgentControlPanel/ (Source code for the GUI)
|   |   |-- WinBridgeAgentControlPanel.sln
|   |   |-- WinBridgeAgentControlPanel/
|   |       |-- WinBridgeAgentControlPanel.csproj
|   |       |-- MainWindow.xaml
|   |       |-- ... (other GUI source files)
|   |-- WinBridgeAgentInstaller/    (Installer script and related files)
|   |   |-- WinBridgeAgentInstaller.nsi
|   |   |-- INSTALLER_README.md (original readme, for reference)
|   |   |-- publish_output/         (This will be created and populated during the build)
|   |-- LICENSE.txt
|-- BUILD_AND_DISTRIBUTION_GUIDE.md (This guide)
```

This structure helps keep the components organized. The `publish_output` directory inside `WinBridgeAgentInstaller` is where the compiled service and GUI files will be staged for the NSIS installer.

*(Further sections will be filled in subsequently)*



## 4. Step 1: Setting up the Development Environment

While the final build will be automated using GitHub Actions, setting up a local development environment is crucial for developing, testing, and debugging the projects and the build scripts.

### Installing .NET SDK

*   **Purpose**: To build and publish the WinBridgeAgent service and the WinBridgeAgent Control Panel GUI (both are .NET projects).
*   **Instructions**:
    *   Download the .NET 8 SDK (or the latest compatible version specified by the projects) from the official Microsoft website: [https://dotnet.microsoft.com/download](https://dotnet.microsoft.com/download)
    *   Follow the installation instructions for your operating system (Windows is recommended as these are Windows-specific applications).
    *   Verify the installation by opening a terminal or command prompt and running: `dotnet --version`. You should see the installed SDK version.

### Installing NSIS

*   **Purpose**: To compile the `.nsi` script and create the `WinBridgeAgentInstaller.exe`.
*   **Instructions**:
    *   Download NSIS from its official website: [https://nsis.sourceforge.io/Download](https://nsis.sourceforge.io/Download)
    *   Run the installer and follow the on-screen prompts. Ensure that `makensis.exe` (the NSIS compiler) is added to your system's PATH, or note its installation directory.
    *   Verify the installation by trying to run `makensis /VERSION` in a command prompt. It should display the NSIS version.

### Installing Git

*   **Purpose**: For version control, managing source code, and interacting with GitHub.
*   **Instructions**:
    *   Download Git from its official website: [https://git-scm.com/downloads](https://git-scm.com/downloads)
    *   Follow the installation instructions for your operating system.
    *   Verify the installation by opening a terminal or command prompt and running: `git --version`.

### Code Editor/IDE

*   **Purpose**: For viewing, editing, and debugging the source code.
*   **Recommendations**:
    *   **Visual Studio**: A full-featured IDE for .NET development, excellent for C# and WPF projects. (Community edition is free for individual developers and open-source projects).
    *   **Visual Studio Code (VS Code)**: A lightweight but powerful source code editor with excellent support for C# (via extensions) and Git.
    *   **JetBrains Rider**: A cross-platform .NET IDE.
*   **Installation**: Download and install your chosen editor from its official website.

## 5. Step 2: Obtaining the Source Code

This step describes how to get the project files onto your local machine.

### Cloning from GitHub (Recommended for Collaboration)

If the project is already hosted on GitHub (which it will be for GitHub Actions):

1.  Navigate to the GitHub repository page in your web browser.
2.  Click the "Code" button and copy the repository URL (HTTPS or SSH).
3.  Open a terminal or Git Bash.
4.  Navigate to the directory where you want to clone the project.
5.  Run the command: `git clone <repository_url>` (e.g., `git clone https://github.com/your-username/WinBridgeAgent_Distribution.git`)

This will download all project files, including the directory structure outlined previously, and initialize a local Git repository.

### Arranging Provided Source Files (If Starting Locally)

If you have received the source code as separate ZIP files or directories, you need to arrange them according to the project structure outlined in [Section 3. Project Structure Overview](#project-structure-overview). This structure is important for the build scripts and GitHub Actions workflow to locate the files correctly.

Ensure your main project directory (e.g., `WinBridgeAgent_Distribution/`) contains:
*   `WinBridgeAgent/` (service source)
*   `WinBridgeAgentAddons/WinBridgeAgentControlPanel/` (GUI source)
*   `WinBridgeAgentAddons/WinBridgeAgentInstaller/` (installer script, `LICENSE.txt` should also be here or in the root of `WinBridgeAgentAddons` to be copied to the installer directory later)
*   `WinBridgeAgentAddons/LICENSE.txt`

*(The guide will continue with compilation steps, then GitHub Actions setup)*



## 6. Step 3: Compiling the WinBridgeAgent Service

These steps detail how to compile the WinBridgeAgent service from its source code. These commands can be run locally for testing or adapted into a GitHub Actions workflow.

### Navigating to the Service Project Directory

Open your terminal or command prompt.
Navigate to the directory containing the service's `.csproj` file. Based on our example structure:

```bash
cd path/to/WinBridgeAgent_Distribution/WinBridgeAgent/WinBridgeAgent
```

Replace `path/to/` with the actual path to your `WinBridgeAgent_Distribution` directory.

### Restoring Dependencies

Before building, restore the NuGet packages required by the project:

```bash
dotnet restore WinBridgeAgent.csproj
```

Or simply `dotnet restore` if you are in the directory containing the `.csproj` file.

### Building the Service

Build the service in Release configuration:

```bash
dotnet build WinBridgeAgent.csproj -c Release
```

This command compiles the project. The output will typically be in a subdirectory like `bin/Release/net8.0/` (the .NET version might differ).

### Publishing the Service (Self-Contained)

For the installer, you need a self-contained deployment so that the service can run on machines without the .NET runtime pre-installed. Publish the service for the `win-x64` runtime identifier (adjust if targeting other architectures):

```bash
dotnet publish WinBridgeAgent.csproj -c Release -r win-x64 --self-contained true -o ../../publish_service
```

*   `-c Release`: Specifies the Release configuration.
*   `-r win-x64`: Specifies the target runtime (Windows 64-bit). Change if needed (e.g., `win-x86`).
*   `--self-contained true`: Includes the .NET runtime with the application.
*   `-o ../../publish_service`: Specifies the output directory. This command places the published files in `WinBridgeAgent_Distribution/WinBridgeAgent/publish_service/`. You can adjust this path as needed. This output will later be copied to the NSIS installer's staging area.

After this step, the `WinBridgeAgent_Distribution/WinBridgeAgent/publish_service/` directory will contain `WinBridgeAgent.exe` and all its dependencies, ready to be packaged.

## 7. Step 4: Compiling the WinBridgeAgent Control Panel GUI

These steps detail how to compile the WinBridgeAgent Control Panel GUI. Similar to the service, these commands can be run locally or in a CI environment.

### Navigating to the GUI Project Directory

In your terminal or command prompt, navigate to the directory containing the GUI's `.csproj` file:

```bash
cd path/to/WinBridgeAgent_Distribution/WinBridgeAgentAddons/WinBridgeAgentControlPanel/WinBridgeAgentControlPanel
```

### Restoring Dependencies (GUI)

Restore the NuGet packages for the GUI project:

```bash
dotnet restore WinBridgeAgentControlPanel.csproj
```

### Building the GUI

Build the GUI in Release configuration:

```bash
dotnet build WinBridgeAgentControlPanel.csproj -c Release
```

The output will typically be in a subdirectory like `bin/Release/net8.0-windows/` (the target framework moniker might vary for WPF projects).

### Publishing the GUI (Self-Contained)

Publish the GUI as a self-contained application for `win-x64`:

```bash
dotnet publish WinBridgeAgentControlPanel.csproj -c Release -r win-x64 --self-contained true -o ../../../publish_gui
```

*   `-o ../../../publish_gui`: Specifies the output directory. This command places the published files in `WinBridgeAgent_Distribution/WinBridgeAgentAddons/publish_gui/`. Adjust as needed.

After this step, the `WinBridgeAgent_Distribution/WinBridgeAgentAddons/publish_gui/` directory will contain `WinBridgeAgentControlPanel.exe` and all its dependencies.

*(The guide will continue with preparing files for the installer and building the NSIS installer)*



## 8. Step 5: Preparing Files for the Installer

Before building the NSIS installer, you need to gather all the necessary compiled application files and the license file into a staging area that the NSIS script expects. The provided `WinBridgeAgentInstaller.nsi` script expects these files to be in a directory named `publish_output` relative to the script itself.

### Creating the `publish_output` Directory

If it doesn't already exist, create this directory:

```bash
# Assuming you are in WinBridgeAgent_Distribution directory
mkdir -p WinBridgeAgentAddons/WinBridgeAgentInstaller/publish_output
```

Or create it manually using your file explorer.

### Copying Service Files

Copy the contents of the service publish directory (e.g., `WinBridgeAgent_Distribution/WinBridgeAgent/publish_service/`) into the installer's `publish_output` directory.

Using command line (example from `WinBridgeAgent_Distribution` root):

```bash
# For Windows (PowerShell or Command Prompt)
xcopy /E /I /Y WinBridgeAgent\publish_service\* WinBridgeAgentAddons\WinBridgeAgentInstaller\publish_output\

# For Linux/macOS (if building cross-platform or for reference)
cp -R WinBridgeAgent/publish_service/* WinBridgeAgentAddons/WinBridgeAgentInstaller/publish_output/
```

Ensure all files, including `WinBridgeAgent.exe`, `appsettings.json`, DLLs, and the `runtimes` folder (if present), are copied.

### Copying GUI Files

Copy the contents of the GUI publish directory (e.g., `WinBridgeAgent_Distribution/WinBridgeAgentAddons/publish_gui/`) into the same installer's `publish_output` directory.

Using command line (example from `WinBridgeAgent_Distribution` root):

```bash
# For Windows (PowerShell or Command Prompt)
xcopy /E /I /Y WinBridgeAgentAddons\publish_gui\* WinBridgeAgentAddons\WinBridgeAgentInstaller\publish_output\

# For Linux/macOS
cp -R WinBridgeAgentAddons/publish_gui/* WinBridgeAgentAddons/WinBridgeAgentInstaller/publish_output/
```

This will add `WinBridgeAgentControlPanel.exe` and its dependencies to the `publish_output` directory alongside the service files.

### Copying `LICENSE.txt`

The NSIS script (`WinBridgeAgentInstaller.nsi`) is configured to look for `LICENSE.txt` in the same directory as the script itself. Ensure your `LICENSE.txt` file is located at:
`WinBridgeAgent_Distribution/WinBridgeAgentAddons/WinBridgeAgentInstaller/LICENSE.txt`

If your main `LICENSE.txt` is in `WinBridgeAgent_Distribution/WinBridgeAgentAddons/`, copy it:

```bash
# For Windows (PowerShell or Command Prompt)
copy WinBridgeAgentAddons\LICENSE.txt WinBridgeAgentAddons\WinBridgeAgentInstaller\LICENSE.txt

# For Linux/macOS
cp WinBridgeAgentAddons/LICENSE.txt WinBridgeAgentAddons/WinBridgeAgentInstaller/LICENSE.txt
```

At this point, the `WinBridgeAgentAddons/WinBridgeAgentInstaller/publish_output/` directory should contain all files for the service and the GUI, and `LICENSE.txt` should be alongside `WinBridgeAgentInstaller.nsi`.

## 9. Step 6: Building the NSIS Installer

With the application files prepared, you can now compile the NSIS script to create the installer executable.

### Navigating to the Installer Script Directory

In your terminal or command prompt, navigate to the directory containing the `WinBridgeAgentInstaller.nsi` script:

```bash
cd path/to/WinBridgeAgent_Distribution/WinBridgeAgentAddons/WinBridgeAgentInstaller
```

### Running the NSIS Compiler (`makensis`)

Execute the `makensis` command, providing the script file as an argument:

```bash
makensis WinBridgeAgentInstaller.nsi
```

NSIS will process the script. You will see output in the console indicating the progress:

*   It will read the script and process commands.
*   It will compress and add files from the `publish_output` directory (and `LICENSE.txt`).
*   It will generate the installer executable.

If there are errors in the script or missing files, `makensis` will report them.

### Locating the Installer Executable

If the compilation is successful, `WinBridgeAgentInstaller.exe` (or the name specified by `OutFile` in the script) will be created in the same directory as the `.nsi` script (i.e., `WinBridgeAgent_Distribution/WinBridgeAgentAddons/WinBridgeAgentInstaller/`).

This `WinBridgeAgentInstaller.exe` is the final distributable installer for end-users.

*(The guide will next cover setting up GitHub Actions for automated builds)*



## 10. Step 7: Automating Builds with GitHub Actions

To automate the compilation of the service, GUI, and the NSIS installer, we will use GitHub Actions. This allows for a consistent build process triggered by code changes or manually.

### Creating the Workflow File

1.  In the root of your `WinBridgeAgent_Distribution` GitHub repository, create a directory named `.github` if it doesn't already exist.
2.  Inside `.github`, create another directory named `workflows`.
3.  Place the GitHub Actions workflow file (e.g., `build-installer.yml`, as provided in the previous step) into the `.github/workflows/` directory.

Your repository structure should now include:

```
WinBridgeAgent_Distribution/
|-- .github/
|   |-- workflows/
|       |-- build-installer.yml
|-- WinBridgeAgent/              (Service source)
|-- WinBridgeAgentAddons/        (GUI and Installer script source)
|-- ... (other project files)
```

### Understanding the GitHub Actions Workflow (`build-installer.yml`)

The provided `build-installer.yml` file defines the automated build process. Here’s a high-level overview:

*   **Triggers**: The workflow is configured to run automatically on:
    *   `push` events to the `main` branch (or your default branch).
    *   `pull_request` events targeting the `main` branch.
    *   `workflow_dispatch`, allowing you to trigger it manually from the GitHub Actions tab.
*   **Runner**: It uses `windows-latest` as the runner environment, which is necessary for building Windows applications and using NSIS.
*   **Steps**:
    1.  **Checkout repository**: Downloads your repository code to the runner.
    2.  **Setup .NET SDK**: Installs the specified .NET SDK version.
    3.  **Setup NSIS**: Installs NSIS using Chocolatey and adds it to the PATH.
    4.  **Restore, Build, Publish (Service)**: Performs the `dotnet restore`, `dotnet build`, and `dotnet publish` commands for the WinBridgeAgent service, outputting to a `publish_service` directory.
    5.  **Restore, Build, Publish (GUI)**: Performs the `dotnet restore`, `dotnet build`, and `dotnet publish` commands for the WinBridgeAgent Control Panel GUI, outputting to a `publish_gui` directory.
    6.  **Prepare Installer Files**: Creates the `publish_output` directory for NSIS and copies the published service files, GUI files, and `LICENSE.txt` into it.
    7.  **Build NSIS Installer**: Runs `makensis` on your `WinBridgeAgentInstaller.nsi` script, which uses the files in `publish_output` to create `WinBridgeAgentInstaller.exe`.
    8.  **Upload Installer Artifact**: Uploads the generated `WinBridgeAgentInstaller.exe` as an artifact associated with the workflow run. This artifact can then be downloaded.

### How the Workflow Uses Project Files

*   The workflow assumes the project structure outlined in [Section 3](#project-structure-overview).
*   It expects the service project to be at `WinBridgeAgent/WinBridgeAgent/WinBridgeAgent.csproj`.
*   It expects the GUI project to be at `WinBridgeAgentAddons/WinBridgeAgentControlPanel/WinBridgeAgentControlPanel/WinBridgeAgentControlPanel.csproj`.
*   It expects the NSIS script to be at `WinBridgeAgentAddons/WinBridgeAgentInstaller/WinBridgeAgentInstaller.nsi`.
*   It expects `LICENSE.txt` to be at `WinBridgeAgentAddons/LICENSE.txt` (and copies it to the installer directory).

Adjust paths in the `build-installer.yml` file if your project structure differs.

### Triggering the Workflow and Downloading Artifacts

1.  **Commit and Push**: Commit the `build-installer.yml` file (and any other project changes) to your GitHub repository and push to the `main` branch.
    ```bash
    git add .github/workflows/build-installer.yml
    git commit -m "Add GitHub Actions workflow for building installer"
    git push
    ```
2.  **Monitor Workflow Run**:
    *   Go to your repository on GitHub.
    *   Click on the "Actions" tab.
    *   You should see the workflow running or queued. Click on it to view its progress and logs.
3.  **Download Installer Artifact**:
    *   Once the workflow completes successfully, on the summary page for that workflow run, you will find an "Artifacts" section.
    *   The `WinBridgeAgentInstaller` artifact (containing `WinBridgeAgentInstaller.exe`) will be listed there.
    *   Click on the artifact name to download it as a ZIP file. Extract the ZIP to get the installer executable.

This `WinBridgeAgentInstaller.exe` is the result of the automated build process and is ready for distribution through your chosen channels.

## 11. Step 8: Local Development and Testing

While GitHub Actions automates the final build, you will still perform most development and testing locally. The manual compilation steps outlined in [Step 3](#step-3-compiling-the-winbridgeagent-service) through [Step 6](#step-6-building-the-nsis-installer) are essential for this local workflow.

*   Use your local environment to write and debug code for the service and GUI.
*   Test building the .NET projects locally.
*   Test building the NSIS installer locally to ensure the script works and packages files correctly before relying on the GitHub Actions workflow.

## 12. Conclusion

This guide has provided a comprehensive walkthrough for setting up your development environment, compiling the WinBridgeAgent service and GUI, preparing files for the installer, building the NSIS installer, and automating the entire build process using GitHub Actions. By following these steps, you can ensure a consistent and repeatable build process, producing an installer ready for distribution.

Remember to adapt paths and commands if your project structure or specific versions differ from the examples provided.

